const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

const scoreEl = document.getElementById("score");
const highScoreEl = document.getElementById("highscore");
const restartBtn = document.getElementById("restart");

const GRID = 20;
const SIZE = 20;
const WIDTH = 400;
const HEIGHT = 400;
const gameOverScreen = document.getElementById("gameOver");
const finalScore = document.getElementById("finalScore");
const playAgainBtn = document.getElementById("playAgain");
let snake = [];
let direction = "RIGHT";
let nextDirection = "RIGHT";
let food = {};
let score = 0;
let highScore = Number(localStorage.getItem("snakeHighScore")) || 0;
let gameLoop;
let paused = false;

highScoreEl.textContent = highScore;

function startGame() {
gameOverScreen.classList.add("hidden");
    snake = [
        { x: 200, y: 200 }
    ];

    direction = "RIGHT";
    nextDirection = "RIGHT";
    score = 0;
    paused = false;

    scoreEl.textContent = score;

    spawnFood();
function startGame() {

    gameOverScreen.classList.add("hidden");

    snake = [
        { x: 200, y: 200 }
    ];

    direction = "RIGHT";
    nextDirection = "RIGHT";
    score = 0;
    paused = false;

    scoreEl.textContent = score;

    spawnFood();

    draw(); 

    clearInterval(gameLoop);
    gameLoop = setInterval(update, 150);
}
    clearInterval(gameLoop);
    gameLoop = setInterval(update, 150);

}

function spawnFood() {

    let valid = false;

    while (!valid) {

        food = {
            x: Math.floor(Math.random() * 20) * GRID,
            y: Math.floor(Math.random() * 20) * GRID
        };

        valid = true;

        for (const part of snake) {
            if (part.x === food.x && part.y === food.y) {
                valid = false;
                break;
            }
        }

    }

}function update() {

    if (paused) {
        draw();
        return;
    }

    direction = nextDirection;

    const head = {
        x: snake[0].x,
        y: snake[0].y
    };

    if (direction === "UP") head.y -= GRID;
    if (direction === "DOWN") head.y += GRID;
    if (direction === "LEFT") head.x -= GRID;
    if (direction === "RIGHT") head.x += GRID;

    // Duvara çarpma
   if (
    head.x < 0 ||
    head.y < 0 ||
    head.x >= WIDTH ||
    head.y >= HEIGHT
) {
    gameOver();
    return;
}

}
    }

    // Kendine çarpma
    for (const part of snake) {
        if (part.x === head.x && part.y === head.y) {
            gameOver();
            return;
        }
    }

    snake.unshift(head);

    // Elma yeme
    if (head.x === food.x && head.y === food.y) {

        score++;
        scoreEl.textContent = score;

        if (score > highScore) {
            highScore = score;
            localStorage.setItem("snakeHighScore", highScore);
            highScoreEl.textContent = highScore;
        }

        spawnFood();

        // Skor arttıkça hızlan
        clearInterval(gameLoop);
        const speed = Math.max(60, 150 - score * 5);
        gameLoop = setInterval(update, speed);

    } else {
        snake.pop();
    }

    draw();
}

function draw() {

    ctx.fillStyle = "#111";
    ctx.fillRect(0, 0, WIDTH, HEIGHT);

    // Izgara
    ctx.strokeStyle = "#222";
    for (let i = 0; i <= WIDTH; i += GRID) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i, HEIGHT);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(0, i);
        ctx.lineTo(WIDTH, i);
        ctx.stroke();
    }

    // Elma
    ctx.fillStyle = "#ff3b30";
    ctx.beginPath();
    ctx.arc(food.x + 10, food.y + 10, 8, 0, Math.PI * 2);
    ctx.fill();

    // Yılan
    snake.forEach((part, index) => {

        ctx.fillStyle = index === 0 ? "#00e676" : "#2ecc71";
        ctx.fillRect(part.x + 1, part.y + 1, SIZE - 2, SIZE - 2);

    });

    if (paused) {
        ctx.fillStyle = "rgba(0,0,0,0.5)";
        ctx.fillRect(0, 0, WIDTH, HEIGHT);

        ctx.fillStyle = "white";
        ctx.font = "30px Arial";
        ctx.textAlign = "center";
        ctx.fillText("DURAKLATILDI", WIDTH / 2, HEIGHT / 2);
    }
}

function gameOver() {

    clearInterval(gameLoop);

    finalScore.textContent = score;

    gameOverScreen.classList.remove("hidden");

}

document.addEventListener("keydown", (e) => {

    const key = e.key.toLowerCase();

    if (key === "p") {
        paused = !paused;
        return;
    }

    if ((key === "arrowup" || key === "w") && direction !== "DOWN")
        nextDirection = "UP";

    if ((key === "arrowdown" || key === "s") && direction !== "UP")
        nextDirection = "DOWN";

    if ((key === "arrowleft" || key === "a") && direction !== "RIGHT")
        nextDirection = "LEFT";

    if ((key === "arrowright" || key === "d") && direction !== "LEFT")
        nextDirection = "RIGHT";
});

restartBtn.addEventListener("click", startGame);

startGame();
playAgainBtn.addEventListener("click", startGame);